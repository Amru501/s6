#include <stdio.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <fcntl.h>
#include <stdlib.h>
#include <unistd.h>

int main(int argc, char *argv[])
{
    int n, fd;
    int sock_ctrl, sock_data;

    char buffer[1024];
    char cmd[100];
    char name[100];

    struct sockaddr_in servaddr;

    if (argc != 3) {
        fprintf(stderr, "Usage: ./client <Server_IP> <Port>\n");
        exit(1);
    }

    sock_ctrl = socket(AF_INET, SOCK_STREAM, 0);
    if (sock_ctrl < 0) {
        perror("Control socket creation failed");
        exit(1);
    }

    memset(&servaddr, 0, sizeof(servaddr));
    servaddr.sin_family = AF_INET;
    servaddr.sin_port = htons(atoi(argv[2]));
    inet_pton(AF_INET, argv[1], &servaddr.sin_addr);

    if (connect(sock_ctrl, (struct sockaddr *)&servaddr, sizeof(servaddr)) < 0) {
        perror("Control socket connection failed");
        exit(1);
    }

    printf("Commands:\n");
    printf(" get   - Receive file from server\n");
    printf(" close - Close connection\n");

    while (1) {
        printf("\nEnter command: ");
        scanf("%s", cmd);

        write(sock_ctrl, cmd, strlen(cmd) + 1);

        if (strcmp(cmd, "close") == 0) {
            close(sock_ctrl);
            printf("Connection closed.\n");
            break;
        }

        sock_data = socket(AF_INET, SOCK_STREAM, 0);
        if (sock_data < 0) {
            perror("Data socket creation failed");
            exit(1);
        }

        printf("Enter filename: ");
        scanf("%s", name);
        write(sock_ctrl, name, strlen(name) + 1);

        fd = open(name, O_WRONLY | O_CREAT | O_TRUNC, 0644);
        if (fd < 0) {
            perror("File open failed");
            close(sock_data);
            continue;
        }

        servaddr.sin_port = htons(atoi(argv[2]) + 1);

        if (connect(sock_data, (struct sockaddr *)&servaddr, sizeof(servaddr)) < 0) {
            perror("Data socket connection failed");
            close(fd);
            close(sock_data);
            continue;
        }

        while ((n = read(sock_data, buffer, sizeof(buffer))) > 0) {
            write(fd, buffer, n);
        }

        printf("File received successfully.\n");

        close(fd);
        close(sock_data);
    }

    return 0;
}

