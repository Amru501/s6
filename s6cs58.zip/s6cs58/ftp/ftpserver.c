#include <stdio.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <fcntl.h>
#include <stdlib.h>
#include <unistd.h>

#define MAX 100

int main(int argc, char *argv[])
{
    int n, fd;
    int sock_ctrl, sock_data;
    int listen_control, listen_data;

    char cmd[MAX];
    char name[MAX];
    char buffer[MAX];

    struct sockaddr_in servaddr, cliaddr;
    socklen_t cli_len = sizeof(cliaddr);

    if (argc != 2) {
        printf("Usage: ./server <port>\n");
        exit(1);
    }

    listen_control = socket(AF_INET, SOCK_STREAM, 0);
    if (listen_control < 0) {
        perror("Control socket creation failed");
        exit(1);
    }

    bzero(&servaddr, sizeof(servaddr));
    servaddr.sin_family = AF_INET;
    servaddr.sin_addr.s_addr = htonl(INADDR_ANY);
    servaddr.sin_port = htons(atoi(argv[1]));

    if (bind(listen_control, (struct sockaddr *)&servaddr, sizeof(servaddr)) < 0) {
        perror("Control bind failed");
        exit(1);
    }

    listen(listen_control, 5);

    listen_data = socket(AF_INET, SOCK_STREAM, 0);
    if (listen_data < 0) {
        perror("Data socket creation failed");
        exit(1);
    }

    servaddr.sin_port = htons(atoi(argv[1]) + 1);

    if (bind(listen_data, (struct sockaddr *)&servaddr, sizeof(servaddr)) < 0) {
        perror("Data bind failed");
        exit(1);
    }

    listen(listen_data, 5);

    printf("Server started...\n");

    while (1) {
        sock_ctrl = accept(listen_control, (struct sockaddr *)&cliaddr, &cli_len);
        if (sock_ctrl < 0) {
            perror("Control accept failed");
            continue;
        }

        if (fork() == 0) {
            close(listen_control);

            while (1) {
                bzero(cmd, MAX);
                n = read(sock_ctrl, cmd, MAX);
                if (n <= 0)
                    break;

                cmd[n] = '\0';

                if (strcmp(cmd, "close") == 0)
                    break;

                bzero(name, MAX);
                read(sock_ctrl, name, MAX);

                sock_data = accept(listen_data, (struct sockaddr *)&cliaddr, &cli_len);
                if (sock_data < 0) {
                    perror("Data accept failed");
                    break;
                }

                fd = open(name, O_RDONLY);
                if (fd < 0) {
                    sprintf(buffer, "FILE NOT FOUND (PID=%d)", getpid());
                    write(sock_data, buffer, strlen(buffer));
                } else {
                    while ((n = read(fd, buffer, MAX)) > 0) {
                        write(sock_data, buffer, n);
                    }
                    close(fd);
                }

                close(sock_data);
            }

            close(sock_ctrl);
            close(listen_data);
            exit(0);
        }

        close(sock_ctrl);
    }

    close(listen_control);
    close(listen_data);

    return 0;
}

